# SPDX-FileCopyrightText: 2024-present David LoBosco <5651124+dqlobo@users.noreply.github.com>
#
# SPDX-License-Identifier: AGPL-3.0-only
